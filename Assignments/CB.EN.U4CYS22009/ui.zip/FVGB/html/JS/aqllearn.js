function goToAnotherPage() {
    // Redirect to the desired page
    window.location.href = "learnhtml.html";
  }
  function goToAnotherPage1()
{
    window.location.href="referencehtml.html";
}
function goToAnotherPage2()
{
    window.location.href="htmlcertificate.html";
}
function cssPage()
{
    window.location.href="csslearn.html";
}
function cssPage1()
{
    window.location.href="referencecss.html";
}
function cssPage2()
{
    window.location.href="csscertificate.html";
}
function javaPage()
{
    window.location.href="javascriptlearn.html"
}
function javaPage1()
{
    window.location.href="javascriptreference.html";
}
function javaPage2()
{
    window.location.href="javascriptcertificate.html";
}
function PythonPage()
{
    window.location.href="phytonlearn.html"
}
function PythonPage1()
{
    window.location.href="phytonreference.html";
}
function PythonPage2()
{
    window.location.href="phytoncertificate.html";
}
function SQLPage()
{
    window.location.href="aqllearn.html";
}
function SQLPage1()
{
    window.location.href="sqlreference.html";
}
function SQLPage2()
{
    window.location.href="sqlcertificate.html";
}
function SignUPPage()
{
  window.location.href="signup1.html";
}
function LoginPage()
{
    window.location.href="login.html";
}
function htmllink() {
  document.getElementById("HTMLlinking").scrollIntoView();
}
function CSSlink() {
  document.getElementById("CSSlinking").scrollIntoView();
}
function javalink() {
  document.getElementById("JAVAlinking").scrollIntoView();
}
function pythonlink() {
  document.getElementById("pythonlinking").scrollIntoView();
}
function sqllink() {
  document.getElementById("sqLlinking").scrollIntoView();
}
function goToAnotherPage2()
{
window.location.href="home.html";
}