window.onload = function() {
    // Example JavaScript code
    var heading = document.querySelector("h1");
    heading.addEventListener("click", function() {
      alert("You clicked the heading!");
    });
  };